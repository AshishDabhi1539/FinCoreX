package com.tss.hello_spring_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringAppApplication.class, args);
	}

}
